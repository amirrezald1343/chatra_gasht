<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Agency extends Model
{
    protected  $guarded=[];

    function media(){
        return $this->belongsTo(Media::class);
    }

    function permission() {
        return $this->belongsTo(Permission::class)->with('sections');
    }

}
