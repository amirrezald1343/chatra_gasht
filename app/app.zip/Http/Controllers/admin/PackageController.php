<?php

namespace App\Http\Controllers\admin;

use App\Agency;
use App\City;
use App\Destination;
use App\Image;
use App\Level;
use App\Map;
use App\Package;
use App\Price;
use App\Service;
use App\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\TmpSession;
use App\TmpImage;
use App\Media;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;


class PackageController extends Controller
{
    private $model = 'App\Package';
    private $paginate = 15;
    const NAME = 'Package';
    const FANAME = 'تور';


    public function index()
    {

        $agency_id = Agency::where('user_id', auth()->user()->id)->first();
        if (auth()->user()->isSuperAdmin()) {
            $items = $this->model::with('cities', 'levels', 'maps', 'prices', 'images', 'agency', 'services', 'city')->paginate($this->paginate);
        } else {
            $items = $this->model::with('cities', 'levels', 'maps', 'prices', 'images', 'agency', 'services', 'city')->where('agency_id', auth()->user()->id)->orderBy('id', 'desc')->paginate($this->paginate);
        }


        // dd($items[0]['agency']['company']);

        return view(findView(), [
            'NAME' => self::NAME,
            'FANAME' => self::FANAME,
            'items' => $items,
        ]);
    }

    public function create()
    {


        /*------------check_TmpImage-----------------*/
        $images = TmpImage::where('user_id', auth()->user()['id'])->distinct()->get('package_id'); //changeObject to array - id
        foreach ($images as $key => $value) {
            $image = TmpImage::where('package_id', $value->package_id)->first();
            $time1 = \Carbon\Carbon::parse($image->created_at);
            $time2 = \Carbon\Carbon::now()->addDay(-1);
            if ($time1->timestamp < $time2->timestamp) {
                $images_past_history = TmpImage::where('package_id', $value->package_id)->get();
                foreach ($images_past_history as $value_images_past_history) {
                    File::delete($value_images_past_history->media['path']); //changeObject to array - path
                    Media::where('id', $value_images_past_history->media['id'])->delete(); //changeObject to array - id
                }
            }
        }
        /*------------Create_Session_TmpTime-----------------*/
        $tmptime = array();
        if (\Session()->exists('tmptime')) {
            $tmptime = session()->get('tmptime');
            array_unshift($tmptime, time());
            \Session(['tmptime' => $tmptime]);
        } else {
            array_unshift($tmptime, time());
            \Session(['tmptime' => $tmptime]);
        }
        /*------------Service-----------------*/
        $Service = Service::where(['status' => '1'])->get();
        /*------------Service-----------------*/
        if (auth()->user()->role == 'superAdmin') {
            $agencies = Agency::where(['status' => '1'])->pluck('company', 'id')->ToArray();
        } else {
            $agencies = null;
        }


        return view(findView(), [
            'NAME' => self::NAME,
            'FANAME' => self::FANAME,
            'tmptime' => $tmptime,
            'Service' => $Service,
            'agencies' => $agencies
        ]);
    }

    public function uploadimg(Request $request, $tmptime)
    {
        $model = TmpImage::create([
            'user_id' => auth()->user()->id,
            'package_id' => $tmptime,
        ]);
        $File_Name = $model->id . time() . '.' . getFileExtension($request->file('file')->getClientOriginalName());
        $path = 'Package' . '/' . Carbon::now()->addDay()->year . '/' . Carbon::now()->addDay()->month . '/' . Carbon::now()->addDay()->day;
        if ($request->file->storeAs($path, $File_Name, 'public')) {
            $media = new Media();
            $media->name = $request->file('file')->getClientOriginalName();
            $media->path = 'storage/' . $path . '/' . $File_Name;
            $media->user_id = Auth::user()->id;
            $media->save();
            $model->update(['media_id' => $media->id]);
        }
        return $model->id;
    }

    public function deletimg(Request $request)
    {
        $first = TmpImage::where(['id' => $request->id, 'user_id' => auth()->user()->id])->first();
        File::delete($first->media->path);
        Media::where('id', $first->media->id)->delete();
        return 'ok';
    }

    public function store(Request $request)
    {


        if (auth()->user()->role == 'superAdmin') {

            $agencyFieldId = $request['agency'];

            $this->validate($request, [
                'start_in' => 'required',
                'number_nights' => 'required|integer',
                'origin' => 'required|integer',
                'cities' => 'required',
                'Services' => 'nullable',
                'travel_method' => 'required|in:aerial,earthy,marine',
                'vehicle_type' => 'required',
                'description' => 'required',
                'agency' => 'required',
            ]);


        } else {
            $this->validate($request, [
                'start_in' => 'required',
                'number_nights' => 'required|integer',
                'origin' => 'required|integer',
                'cities' => 'required',
                'Services' => 'nullable',
                'travel_method' => 'required|in:aerial,earthy,marine',
                'vehicle_type' => 'required',
                'description' => 'required',
            ]);

            $agencyFieldId = auth()->user()->id;
            //Agency::where('user_id', auth()->user()->id)->first()['id'];
        }


        if (!$request->has('moment')) $request->merge(['moment' => '0']);
        if (!$request->has('indoors')) $request->merge(['indoors' => '0']);
        $title = 'تور ';
        foreach (json_decode($request->cities) as $key => $value) {
            $title = $title . $value->title_fa . ((count(json_decode($request->cities)) == ($key + 1)) ? '' : ' + ');
        }
        /*------------Create_Package-----------------*/


        $model = Package::create([
            'title' => $title,
            'start_in' => \Morilog\Jalali\CalendarUtils::createDatetimeFromFormat('Y/m/d H:i:s', ($request->start_in . ' 00:00:00')),
            'number_nights' => $request->number_nights,
            'origin' => $request->origin,
            'travel_method' => $request->travel_method,
            'vehicle_type' => $request->vehicle_type,
            'description' => $request->description,
            'additional_services' => $request->additional_services,
            'documents' => $request->documents,
            'rules' => $request->rules,
            'agency_id' => $agencyFieldId,
            'tourType' => $request->tourType,
            'moment' => $request->moment,
            'indoors' => $request->indoors,
        ]);
        if ($model) {


            /*------------Cities-----------------*/
            $Maindestinations = [];
            $destinations = [];
            $continents = [];
            if ($request->continents and (count(json_decode($request->continents)) > 0)) {
                $destinations = explode(',', collect(json_decode($request->continents))->implode('id', ','));
                foreach ($destinations as $key => $value) {
                    $Maindestinations[$value] = ['type' => 'continent'];
                }
            }
            $destinations = [];
            $countries = [];
            if ($request->countries and (count(json_decode($request->countries)) > 0)) {
                $destinations = explode(',', collect(json_decode($request->countries))->implode('id', ','));
                foreach ($destinations as $key => $value) {
                    $Maindestinations[$value] = ['type' => 'country'];
                }
            }
            $destinations = [];
            $cities = [];
            if ($request->cities and (count(json_decode($request->cities)) > 0)) {
                $destinations = explode(',', collect(json_decode($request->cities))->implode('id', ','));
                foreach ($destinations as $key => $value) {
                    $Maindestinations[$value] = ['type' => 'city'];
                }
            }
            if (!empty($Maindestinations)) {
                $model->cities()->sync($Maindestinations);
            }
            /*------------Services-----------------*/
            if ($request->services) {
                $services = explode(',', collect(json_decode($request->services))->implode('id', ','));
                $model->services()->sync($services);
            }
            /*------------Levels-----------------*/
            if ($request->title_level) {
                foreach ($request->title_level as $key => $value) {
                    if ($value) {
                        Level::create([
                            'title' => $value,
                            'description' => $request->description_level[$key],
                            'number' => $key + 1,
                            'package_id' => $model->id,
                        ]);
                    }
                }
            }
            /*------------Map-----------------*/
            if ($request->mapsednumber) {
                foreach ($request->mapsednumber as $key => $value) {
                    Map::create([
                        'number' => $value,
                        'lat' => $request->lat[$key],
                        'lon' => $request->lng[$key],
                        'title' => $request->mapsedname[$key],
                        'package_id' => $model->id,
                    ]);
                }
            }
            /*------------Prices-----------------*/
            if ($request->name_price_package) {
                foreach ($request->name_price_package as $key => $value) {
                    Price::create([
                        'name' => $value,
                        'type' => $request->type_price_package[$key],
                        'star' => $request->star_price_package[$key],
                        'price' => $request->amount_price_package[$key],
                        'price_dollar' => $request->amount_price_dollar_package[$key],
                        'package_id' => $model->id,
                    ]);
                }
            }
            /*------------Images-----------------*/
            if ($request->tmptime) {
                if (key_exists($request->tmptime, array_flip(session()->get('tmptime')))) {
                    $images = TmpImage::where(['user_id' => auth()->user()->id, 'package_id' => $request->tmptime])->get();
                    if ($images->count() > 0) {
                        foreach ($images as $value) {
                            Image::create([
                                'title' => $request->titleimg[$value->id],
                                'media_id' => $value->media_id,
                                'package_id' => $model->id,
                            ]);
                            $value->delete();
                        }
                    }
                }
            }
            redirect()->back()->with(['success' => self::FANAME . ' ' . 'با موفقیت ایجاد شد!']);
        }
        return back()->with(['error', __('admin.failed!')]);
    }

    public function show(Package $package)
    {

    }

    public function edit($id)
    {


        $agency_id = User::with('agency')->where('id', auth()->user()->id)->first()->id;
        $model = $this->model::with('cities', 'levels', 'maps', 'prices', 'images', 'agency', 'services', 'city')->find($id);
        /*------------Service-----------------*/
        $Service = Service::where(['status' => '1'])->get();

        if ($model->agency_id != Auth::user()->id AND !auth()->user()->isSuperAdmin()) {
            return abort(401);
        }


        return view('admin.Package.edit', [
            'NAME' => self::NAME,
            'FANAME' => self::FANAME,
            'model' => $model,
            'Service' => $Service,
        ]);
    }

    public function MainUploadImg(Request $request, $id)
    {
        $model = Image::create([
            'package_id' => $id,
        ]);
        $File_Name = $model->id . time() . '.' . getFileExtension($request->file('file')->getClientOriginalName());
        $path = 'Package' . '/' . Carbon::now()->addDay()->year . '/' . Carbon::now()->addDay()->month . '/' . Carbon::now()->addDay()->day;
        if ($request->file->storeAs($path, $File_Name, 'public')) {
            $media = new Media();
            $media->name = $request->file('file')->getClientOriginalName();
            $media->path = 'storage/' . $path . '/' . $File_Name;
            $media->user_id = Auth::user()->id;
            $media->save();
            $model->update(['media_id' => $media->id]);
        }
        return $model->id;
    }

    public function MainDeleteImg(Request $request)
    {
        if ($request->type == 'IMG') {
            $first = Image::where(['id' => $request->id])->first();
            File::delete($first->media->path);
            Media::where('id', $first->media->id)->delete();
            return 'ok';
        } elseif ($request->type == 'TMP') {
            $first = Image::where(['id' => $request->id])->first();
            File::delete($first->media->path);
            Media::where('id', $first->media->id)->delete();
            return 'ok';
        }
    }

    public function update(Request $request, $id)
    {

        if (auth()->user()->role == 'superAdmin') {

            $agencyFieldId = $request['agency'];

            $this->validate($request, [
                'start_in' => 'required',
                'number_nights' => 'required|integer',
                'origin' => 'required|integer',
                'cities' => 'required',
                'Services' => 'nullable',
                'travel_method' => 'required|in:aerial,earthy,marine',
                'vehicle_type' => 'required',
                'description' => 'required',
                'agency' => 'required',
            ]);
        } else {

            $this->validate($request, [
                'start_in' => 'required',
                'number_nights' => 'required|integer',
                'origin' => 'required|integer',
                'cities' => 'required',
                'Services' => 'nullable',
                'travel_method' => 'required|in:aerial,earthy,marine',
                'vehicle_type' => 'required',
                'description' => 'required',
            ]);

            $agencyFieldId = $agencyFieldId = auth()->user()->id;
        }


        if (!$request->has('moment')) $request->merge(['moment' => '0']);
        if (!$request->has('indoors')) $request->merge(['indoors' => '0']);
        $title = 'تور ';
        foreach (json_decode($request->cities) as $key => $value) {
            $title = $title . $value->title_fa . ((count(json_decode($request->cities)) == ($key + 1)) ? '' : ' + ');
        }
        $find = $this->model::find($id);
        $update = $find->update([
            'title' => $title,
            'start_in' => \Morilog\Jalali\CalendarUtils::createDatetimeFromFormat('Y/m/d H:i:s', ($request->start_in . ' 00:00:00')),
            'number_nights' => $request->number_nights,
            'origin' => $request->origin,
            'travel_method' => $request->travel_method,
            'vehicle_type' => $request->vehicle_type,
            'description' => $request->description,
            'agency_id' => $agencyFieldId,
            'additional_services' => $request->additional_services,
            'documents' => $request->documents,
            'rules' => $request->rules,
            'tourType' => $request->tourType,
            'moment' => $request->moment,
            'indoors' => $request->indoors,
        ]);


        if ($update) {
            /*------------Cities-----------------*/
            $Maindestinations = [];
            $destinations = [];
            $continents = [];
            if ($request->continents and (count(json_decode($request->continents)) > 0)) {
                $destinations = explode(',', collect(json_decode($request->continents))->implode('id', ','));
                foreach ($destinations as $key => $value) {
                    $Maindestinations[$value] = ['type' => 'continent'];
                }
            }
            $destinations = [];
            $countries = [];
            if ($request->countries and (count(json_decode($request->countries)) > 0)) {
                $destinations = explode(',', collect(json_decode($request->countries))->implode('id', ','));
                foreach ($destinations as $key => $value) {
                    $Maindestinations[$value] = ['type' => 'country'];
                }
            }
            $destinations = [];
            $cities = [];
            if ($request->cities and (count(json_decode($request->cities)) > 0)) {
                $destinations = explode(',', collect(json_decode($request->cities))->implode('id', ','));
                foreach ($destinations as $key => $value) {
                    $Maindestinations[$value] = ['type' => 'city'];
                }
            }
            if (!empty($Maindestinations)) {
                $find->cities()->detach();
                $find->cities()->syncWithoutDetaching($Maindestinations);
            }
            /*------------Services-----------------*/


            if ($request->services) {
                $services = explode(',', collect(json_decode($request->services))->implode('id', ','));
                $find->services()->detach();
                if ($request->services != "[]") {
                    $find->services()->syncWithoutDetaching($services);
                }
            }

            /*------------Levels-----------------*/
            Level::where('package_id', $id)->delete();
            if ($request->title_level) {
                foreach ($request->title_level as $key => $value) {
                    if ($value) {
                        Level::create([
                            'title' => $value,
                            'description' => $request->description_level[$key],
                            'number' => $key + 1,
                            'package_id' => $id,
                        ]);
                    }
                }
            }
            /*------------Map-----------------*/
            Map::where('package_id', $id)->delete();
            if ($request->mapsednumber) {
                foreach ($request->mapsednumber as $key => $value) {
                    Map::create([
                        'number' => $value,
                        'lat' => $request->lat[$key],
                        'lon' => $request->lng[$key],
                        'title' => $request->mapsedname[$key],
                        'package_id' => $id,
                    ]);
                }
            }
            /*------------Prices-----------------*/
            Price::where('package_id', $id)->delete();
            if ($request->name_price_package) {
                foreach ($request->name_price_package as $key => $value) {
                    Price::create([
                        'name' => $value,
                        'type' => $request->type_price_package[$key],
                        'star' => $request->star_price_package[$key],
                        'price' => $request->amount_price_package[$key],
                        'price_dollar' => $request->amount_price_dollar_package[$key],
                        'package_id' => $id,
                    ]);
                }
            }
            /*------------Images-----------------*/
            $images = Image::where(['package_id' => $id])->get();
            if ($images->count() > 0) {
                foreach ($images as $value) {
                    $value->update([
                        'title' => $request->titleimg[$value->id]
                    ]);
                }
            }
            return redirect()->back()->with(['success' => self::FANAME . ' ' . 'با موفقیت ویرایش شد!']);
        }
        return back()->with(['error', __('admin.failed!')]);
    }

    public function destroy(Package $package)
    {
        //
    }

    public function lisCity(Request $request)
    {

        $cities = City::where('title_fa', 'like', '%' . $request->search . '%')
            ->where('types', 'city')
            ->select('id', 'title_fa')->get();

        return response()->json($cities);
    }

    public function listCountries(Request $request)
    {

        $cities = City::where('title_fa', 'like', '%' . $request->search . '%')
            ->where('types', 'country')
            ->select('id', 'title_fa')->get();

        return response()->json($cities);
    }

    public function listContinents(Request $request)
    {

        $cities = City::where('title_fa', 'like', '%' . $request->search . '%')
            ->where('types', 'continent')
            ->select('id', 'title_fa')->get();

        return response()->json($cities);
    }

    public function listAgencies(Request $request)
    {
        $agencies = Agency::where('company', 'like', '%' . $request->search . '%')->select('id', 'company')->get();
        return response()->json($agencies);
    }
}
