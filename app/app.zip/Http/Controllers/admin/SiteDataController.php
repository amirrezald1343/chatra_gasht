<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\SiteData;
use App\User;

class SiteDataController extends Controller
{

    private $model = 'App\SiteData';
    const NAME = 'Dashboard';
    const FANAME = 'اصلاعات صفحات سایت';

    public function editAbout()
    {
        if (!auth()->user()->isSuperAdmin()) {
            abort(401, 'you do not have access to this madule ');
        }

        $model = $this->model::where('type', 'about')->first();

        //  dd($model);

        $NAME = self::NAME;
        $FANAME='صفحه درباره ما سایت';
        return view('admin.site.about', compact('model', 'NAME','FANAME'));
    }


    public function updateAbout(Request $request)
    {

        if (!auth()->user()->isSuperAdmin()) {
            abort(401, 'you do not have access to this madule ');
        }

        $this->validate($request, [
            'description' => 'required'
        ]);

        $this->model::where('type', 'about')->delete();

        $this->model::create([
            'title' => 'درباره ما سایت',
            'adminID' => auth()->user()->id,
            'body' => $request->description,
            'type' => 'about'
        ]);

        return redirect()->route('admin.adminAbout')->with(['success' => 'متن درباره ما سایت با موفقیت ویرایش شد']);

    }


    public function editContact()
    {

        if (!auth()->user()->isSuperAdmin()) {
            abort(401, 'you do not have access to this madule ');
        }

        $model = $this->model::where('type', 'contact')->first();

        //  dd($model);

        $NAME = self::NAME;
        $FANAME='صفحه تماس با ما سایت';
        return view('admin.site.contact', compact('model', 'NAME','FANAME'));
    }


    public function updateContact(Request $request)
    {

        if (!auth()->user()->isSuperAdmin()) {
            abort(401, 'you do not have access to this madule ');
        }

        $this->validate($request, [
            'description' => 'required'
        ]);

        $this->model::where('type', 'contact')->delete();

        $this->model::create([
            'title' => 'ارتباط با ما سایت',
            'adminID' => auth()->user()->id,
            'body' => $request->description,
            'type' => 'contact'
        ]);

        return redirect()->route('admin.adminContact')->with(['success' => 'متن ارتباط با ما  با موفقیت ویرایش شد']);

    }


    public function editRules()
    {
        if (!auth()->user()->isSuperAdmin()) {
            abort(401, 'you do not have access to this madule ');
        }

        $model = $this->model::where('type', 'rules')->first();

        //  dd($model);

        $NAME = self::NAME;
        $FANAME='صفحه قوانین سایت';
        return view('admin.site.rules', compact('model', 'NAME','FANAME'));
    }


    public function updateRules(Request $request)
    {
        if (!auth()->user()->isSuperAdmin()) {
            abort(401, 'you do not have access to this madule ');
        }

        $this->validate($request, [
            'description' => 'required'
        ]);

        $this->model::where('type', 'rules')->delete();

        $this->model::create([
            'title' => 'قوانین سایت',
            'adminID' => auth()->user()->id,
            'body' => $request->description,
            'type' => 'rules'
        ]);

        return redirect()->route('admin.adminRules')->with(['success' => 'قوانین سایت با موفقیت ویرایش شد']);

    }

}
