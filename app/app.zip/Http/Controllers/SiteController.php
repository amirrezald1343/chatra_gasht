<?php

namespace App\Http\Controllers;

use App\Agency;
use App\Country;
use App\Package;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use App\City;
use App\FavoriteTour;

class SiteController extends Controller
{
    public function index()
    {
        /*------ToursMoment-------*/
        $agencies = Agency::where('status', '1')->pluck('id')->toArray();
        $ToursMoment = Package::where('start_in', '>', date(Carbon::now()->format('Y-m-d')))->whereIn('agency_id', $agencies)->where('status', '1');
        $Date = date(Carbon::now()->addDays(7)->format('Y-m-d'));
        $ToursMoment->Where('start_in', '<=', $Date);
        $ToursMoment->with('cities', 'levels', 'maps', 'prices', 'images', 'agency', 'services', 'city')->orderby('id', 'DESC');
        if ($ToursMoment->count() > 6) {
            $ToursMoment = $ToursMoment->get()->random(6);
        } else {
            $ToursMoment = $ToursMoment->get();
        }

        /* ----------Indoors---------- */
        $ToursIndoors = Package::where('start_in', '>', date(Carbon::now()->format('Y-m-d')))->whereIn('agency_id', $agencies)->where('status', '1')->where('indoors','1');
        $ToursIndoors->with('cities', 'levels', 'maps', 'prices', 'images', 'agency', 'services', 'city')->orderby('id', 'DESC');
        if ($ToursIndoors->count() > 6) {
            $ToursIndoors = $ToursIndoors->get()->random(6);
        } else {
            $ToursIndoors = $ToursIndoors->get();
        }



        $favTours = FavoriteTour::with('countries')->where('favorite_tours.status', 'Y')->get();


        return view('site.index', [
            'ToursMoment' => $ToursMoment,
            'TourIndoors' => $ToursIndoors,
            'FavoriteTours' => $favTours
        ]);
    }


    public function test()
    {
//        $country=file_get_contents('https://mosaferan.net/search/suggest');
//        $country = json_decode($country, true);
//
//        foreach ($country as $key=>$value){
//            if($value['type'] == 'location'){
//                City::create([
//                   'title_fa'=>$value['title_fa'],
//                   'title_en'=>$value['title_en'],
//                   'type'=>$value['type'],
//                   'slug_en'=>$value['slug_en'],
//                   'slug_fa'=>$value['slug_fa'],
//                 ]);
//            }
//        }
        dd('ok');

    }
}
