<?php

namespace App\Http\Controllers;

use App\SiteData;
use App\Agency;
use App\City;
use App\Package;
use App\Price;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Morilog\Jalali\Jalalian;

class TourController extends Controller
{
    private $paginate = 20;


    function search(Request $request, $typeRoute = null, $valueRoute = null)
    {
        /*---------------create-session-request--------------*/
        if ($request->has('destination') && $request->has('destination')) {
            $model = $request->all();
            session(['search' => $request->all()]);
        }

        if (!$request->has('destination') && !$request->has('destination') && session()->has('search')) {
            $request->merge(['start_in' => session()->get('search')['start_in']]);
            $request->merge(['destination' => session()->get('search')['destination']]);
            $model = $request->all();
        }

        if (!$request->page) {
            session(['statusFilter' => 0]);
        }
        if (session()->has('filter') && session()->has('statusFilter') && (session()->get('statusFilter') == 1) && $request->page) {
            $modelFilter = session()->get('filter');
        }


        $agencies = Agency::where('status', '1')->pluck('id')->toArray();
        $Tours = Package::where('start_in', '>=', date(Carbon::now()->format('Y-m-d')))->whereIn('agency_id', $agencies)->where('status', '1');

        /*-----start_in----*/
        if ($request->start_in) {
            $fromDate = date((new Jalalian(\Morilog\Jalali\Jalalian::now()->getYear(), getMonthNumber($request->start_in), 01))->toCarbon()->format('Y-m-d'));
            $toDate = date((new Jalalian(\Morilog\Jalali\Jalalian::now()->getYear(), getMonthNumber($request->start_in) + 1, 01))->addDays(-1)->toCarbon()->format('Y-m-d'));
            $Tours->whereBetween('start_in', [$fromDate, $toDate]);
        }
        /*-----destination----*/
        if ($request->destination) {
            $packages = City::where('id', json_decode($request->destination)->id)->with('packages')->first()->packages;
            $packages = explode(',', collect($packages)->implode('id', ','));
            $Tours->whereIn('id', $packages);
        }


        /*-----Tour(internal,foreign)---*/
        if ($typeRoute == 'destination' && $valueRoute != null) {
            $packages = City::where('id', $valueRoute)->with('packages')->first();
            if ($packages) {
                $packages = explode(',', collect($packages->packages)->implode('id', ','));
                $Tours->whereIn('id', $packages);
            }
        }
        /*-----Tour-Indoors(one,several)---*/
        if ($typeRoute == 'indoors' && $valueRoute != null) {
            if ($valueRoute == 'one') {
                $Tours->where('indoors', '1')->where('number_nights', '=', 1);
            } elseif ($valueRoute == 'several') {
                $Tours->where('indoors', '1')->where('number_nights', '>', 1);
            }
        }
        /*-----Tour-Moment---*/
        if ($typeRoute == 'moment') {
            $Date = date(Carbon::now()->addDays(7)->format('Y-m-d'));
            $Tours->Where('start_in', '<=', $Date);
        }
        /*---------------Filter--------------*/
        $Tours_filter = $Tours->with('city')->get();
        $numberNights = array();
        $origins = array();
        foreach ($Tours_filter as $key => $value) {
            if (!key_exists($value->city->id, $origins)) {
                $origins[$value->city->id] = $value->city->title_fa;
            }
            if (!key_exists($value->number_nights, $numberNights)) {
                $numberNights[$value->number_nights] = $key;
            }
        }
        if (isset($modelFilter)) {
            if (key_exists('origins', $modelFilter)) $Tours->whereIn('origin', $modelFilter['origins']);
            if (key_exists('numberNights', $modelFilter)) $Tours->whereIn('number_nights', $modelFilter['numberNights']);
            if (key_exists('typeTrip', $modelFilter)) $Tours->whereIn('travel_method', $modelFilter['typeTrip']);
            if (key_exists('typeTour', $modelFilter)) $Tours->whereIn('tourType', $modelFilter['typeTour']);
            if (key_exists('stars', $modelFilter)) {
                $packages_id_star = Price::whereIn('star', $modelFilter['stars'])->distinct()->pluck('package_id')->toArray();
                $Tours->whereIn('id', $packages_id_star);
            }
        }

        $Tours = $Tours->with('cities', 'levels', 'maps', 'prices', 'images', 'agency', 'services', 'city')->orderby('id', 'DESC')->paginate($this->paginate);


        return view('site.tour.tourList', [
            'Tours' => $Tours,
            'model' => $model ?? null,
            'origins' => $origins,
            'numberNights' => $numberNights,
            'modelFilter' => $modelFilter ?? '',
        ]);
    }

    function details($id)
    {
        $tour = Package::where(['status' => '1'])->with('cities', 'levels', 'maps', 'prices', 'images', 'agency', 'services', 'city')->findOrFail($id);

//        return $tour;

        if ($tour->agency->status == '1') {
            return view('site.tour.tourDetails', [
                'tour' => $tour,
            ]);
        } else {
            abort('404');
        }
    }

    public function filter(Request $request, $typeRoute = null, $valueRoute = null)
    {
        $model = session()->get('search');
        /*-filter-origin-*/
        $agencies = Agency::where('status', '1')->pluck('id')->toArray();
        $Tours = Package::where('start_in', '>', date(Carbon::now()->format('Y-m-d')))->whereIn('agency_id', $agencies)->where('status', '1');
        /*-----start_in----*/
        if ($model['start_in']) {
            $fromDate = date((new Jalalian(\Morilog\Jalali\Jalalian::now()->getYear(), getMonthNumber($model['start_in']), 01))->toCarbon()->format('Y-m-d'));
            $toDate = date((new Jalalian(\Morilog\Jalali\Jalalian::now()->getYear(), getMonthNumber($model['start_in']) + 1, 01))->addDays(-1)->toCarbon()->format('Y-m-d'));
            $Tours->whereBetween('start_in', [$fromDate, $toDate]);
        }
        /*-----destination----*/
        if ($model['destination']) {
            $packages = City::where('id', json_decode($model['destination'])->id)->with('packages')->first()->packages;
            $packages = explode(',', collect($packages)->implode('id', ','));
            $Tours->whereIn('id', $packages);
        }
        /*-----Tour(internal,foreign)---*/
        if ($typeRoute == 'destination' && $valueRoute != null) {
            $packages = City::where('id', $valueRoute)->with('packages')->first();
            if ($packages) {
                $packages = explode(',', collect($packages->packages)->implode('id', ','));
                $Tours->whereIn('id', $packages);
            }
        }
        /*-----Tour-Indoors(one,several)---*/
        if ($typeRoute == 'indoors' && $valueRoute != null) {
            if ($valueRoute == 'one') {
                $Tours->where('indoors', '1')->where('number_nights', '=', 1);
            } elseif ($valueRoute == 'several') {
                $Tours->where('indoors', '1')->where('number_nights', '>', 1);
            }
        }
        /*-----Tour-Moment---*/
        if ($typeRoute == 'moment') {
            $Date = date(Carbon::now()->addDays(7)->format('Y-m-d'));
            $Tours->Where('start_in', '<=', $Date);
        }
        /*---------------Filter--------------*/
        $Tours_model = $Tours->with('city')->get();
        $numberNights = array();
        $origins = array();
        foreach ($Tours_model as $key => $value) {
            if (!key_exists($value->city->id, $origins)) {
                $origins[$value->city->id] = $value->city->title_fa;
            }
            if (!key_exists($value->number_nights, $numberNights)) {
                $numberNights[$value->number_nights] = $key;
            }
        }
        if ($request->origins) $Tours->whereIn('origin', $request->origins);
        if ($request->numberNights) $Tours->whereIn('number_nights', $request->numberNights);
        if ($request->typeTrip) $Tours->whereIn('travel_method', $request->typeTrip);
        if ($request->typeTour) $Tours->whereIn('tourType', $request->typeTour);
        if ($request->stars) {
            $packages_id_star = Price::whereIn('star', $request->stars)->distinct()->pluck('package_id')->toArray();
            $Tours->whereIn('id', $packages_id_star);
        }

        $Tours = $Tours->with('cities', 'levels', 'maps', 'prices', 'images', 'agency', 'services', 'city')->orderby('id', 'DESC')->paginate($this->paginate);


        $modelFilter = $request->all();
        session(['filter' => $modelFilter]);
        session(['statusFilter' => 1]);

        return view('site.tour.tourList', [
            'Tours' => $Tours,
            'model' => $model,
            'modelFilter' => $modelFilter,
            'origins' => $origins,
            'numberNights' => $numberNights,
        ]);
    }

    public function lisCity(Request $request)
    {
        $cities = City::where('title_fa', 'like', '%' . $request->search . '%')->select('id', 'title_fa')->get();
        return response()->json($cities);
    }


    public function aboutPage()
    {
        $about = SiteData::where('type', 'about')->first();
        return view('site.about', compact('about'));
    }

    public function contactPage()
    {
        $contact = SiteData::where('type', 'contact')->first();
        return view('site.contact', compact('contact'));
    }

    public function rulesPage()
    {
        $rules = SiteData::where('type', 'rules')->first();
        return view('site.rules', compact('rules'));
    }

}
