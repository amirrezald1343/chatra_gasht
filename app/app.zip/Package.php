<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Package extends Model
{
   protected $guarded=[];

    function levels(){
        return $this->hasMany(Level::class);
    }

    function maps(){
        return $this->hasMany(Map::class);
    }

    function prices(){
        return $this->hasMany(Price::class);
    }

    function images(){
        return $this->hasMany(Image::class)->with('media');
    }

    function agency(){
        return $this->belongsTo(Agency::class)->with('media');
    }

    function services() {
        return $this->belongsToMany(Service::class);
    }

    function cities() {
        return $this->belongsToMany(City::class)->withPivot(['type']);
    }

    function city(){
        return $this->belongsTo(City::class,'origin');
    }



}
